
package com.example.warehouse.service;

import com.example.warehouse.dto.request.WarehouseRequest;
import com.example.warehouse.dto.response.WarehouseResponse;
import com.example.warehouse.entity.Warehouse;
import com.example.warehouse.entity.WarehouseInventory;
import com.example.warehouse.enums.WarehouseStatus;
import com.example.warehouse.exception.ResourceNotFoundException;
import com.example.warehouse.repository.WarehouseInventoryRepository;
import com.example.warehouse.repository.WarehouseRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class WarehouseService {
    
    private final WarehouseRepository warehouseRepository;
    private final WarehouseInventoryRepository inventoryRepository;
    private final AuditService auditService;
    
    public WarehouseResponse createWarehouse(WarehouseRequest request) {
        log.info("Creating warehouse: {}", request.getName());
        
        Warehouse warehouse = Warehouse.builder()
                .name(request.getName())
                .location(request.getLocation())
                .capacity(request.getCapacity())
                .description(request.getDescription())
                .status(WarehouseStatus.ACTIVE.name())
                .createdAt(LocalDateTime.now())
                .build();
        
        Warehouse saved = warehouseRepository.save(warehouse);
        auditService.logWarehouseAction(saved.getId(), "CREATE", "ACTIVE");
        return mapToResponse(saved);
    }
    
    @Transactional(readOnly = true)
    public WarehouseResponse getWarehouse(Long id) {
        
        Warehouse warehouse = warehouseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + id));
        return mapToResponse(warehouse);
    }
    
    public WarehouseResponse updateWarehouse(Long id, WarehouseRequest request) {
      
        Warehouse warehouse = warehouseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + id));
        
        warehouse.setName(request.getName());
        warehouse.setLocation(request.getLocation());
        warehouse.setCapacity(request.getCapacity());
        warehouse.setDescription(request.getDescription());
        
        Warehouse updated = warehouseRepository.save(warehouse);
        auditService.logWarehouseAction(updated.getId(), "UPDATE", updated.getStatus());
        return mapToResponse(updated);
    }
    
    public void deactivateWarehouse(Long id) {
       
        Warehouse warehouse = warehouseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + id));
        warehouse.setStatus(WarehouseStatus.INACTIVE.name());
        warehouseRepository.save(warehouse);
        auditService.logWarehouseAction(id, "DEACTIVATE", "INACTIVE");
    }
    
    public void activateWarehouse(Long id) {
 
        Warehouse warehouse = warehouseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + id));
        warehouse.setStatus(WarehouseStatus.ACTIVE.name());
        warehouseRepository.save(warehouse);
        auditService.logWarehouseAction(id, "ACTIVATE", "ACTIVE");
    }
    
    public void deleteWarehouse(Long id) {
      
        Warehouse warehouse = warehouseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + id));
        warehouse.setStatus(WarehouseStatus.DELETED.name());
        warehouseRepository.save(warehouse);
        auditService.logWarehouseAction(id, "DELETE", "DELETED");
    }
    
    @Transactional(readOnly = true)
    public Page<WarehouseResponse> getAllWarehouses(Pageable pageable) {
   
        return warehouseRepository.findAll(pageable)
                .map(this::mapToResponse);
    }
    
    private WarehouseResponse mapToResponse(Warehouse warehouse) {
        int currentStock = inventoryRepository.findByWarehouseId(warehouse.getId())
                .stream().mapToInt(WarehouseInventory::getAvailableQuantity).sum();
        
        return WarehouseResponse.builder()
                .id(warehouse.getId())
                .name(warehouse.getName())
                .location(warehouse.getLocation())
                .capacity(warehouse.getCapacity())
                .status(warehouse.getStatus())
                .description(warehouse.getDescription())
                .createdAt(warehouse.getCreatedAt())
                .updatedAt(warehouse.getUpdatedAt())
                .currentStockLevel(currentStock)
                .utilizationPercentage(warehouse.getCapacity() > 0 ? (double) currentStock / warehouse.getCapacity() * 100 : 0)
                .build();
    }
}