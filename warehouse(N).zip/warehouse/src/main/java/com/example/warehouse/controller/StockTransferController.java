
package com.example.warehouse.controller;

import com.example.warehouse.dto.request.StockTransferRequest;
import com.example.warehouse.dto.response.StockTransferResponse;
import com.example.warehouse.service.StockTransferService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/stock-transfers")
@RequiredArgsConstructor
@Tag(name = "Stock Transfer", description = "APIs for transferring stock between warehouses")
@Slf4j
public class StockTransferController {
    
    private final StockTransferService stockTransferService;
    
    @PostMapping
    @Operation(summary = "Transfer stock between warehouses")
    public ResponseEntity<StockTransferResponse> transferStock(@Valid @RequestBody StockTransferRequest request) {
        log.info("REST request to transfer stock from warehouse {} to {}", request.getSourceWarehouseId(), request.getTargetWarehouseId());
        StockTransferResponse response = stockTransferService.transferStock(request);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/{transferId}/complete")
    @Operation(summary = "Complete a stock transfer")
    public ResponseEntity<StockTransferResponse> completeTransfer(@PathVariable Long transferId) {
        log.info("REST request to complete transfer with id: {}", transferId);
        StockTransferResponse response = stockTransferService.completeTransfer(transferId);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/{transferId}/cancel")
    @Operation(summary = "Cancel a stock transfer")
    public ResponseEntity<StockTransferResponse> cancelTransfer(@PathVariable Long transferId) {
        log.info("REST request to cancel transfer with id: {}", transferId);
        StockTransferResponse response = stockTransferService.cancelTransfer(transferId);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping
    @Operation(summary = "Get all stock transfers")
    public ResponseEntity<Page<StockTransferResponse>> getAllTransfers(Pageable pageable) {
        log.debug("REST request to get all transfers");
        Page<StockTransferResponse> transfers = stockTransferService.getAllTransfers(pageable);
        return ResponseEntity.ok(transfers);
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get transfer by ID")
    public ResponseEntity<StockTransferResponse> getTransferById(@PathVariable Long id) {
        log.debug("REST request to get transfer with id: {}", id);
        StockTransferResponse response = stockTransferService.getTransferById(id);
        return ResponseEntity.ok(response);
    }
}