
package com.example.warehouse.dto.request;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StockTransferRequest {
    
    @NotNull(message = "Source warehouse ID is required")
    @Positive(message = "Source warehouse ID must be positive")
    private Long sourceWarehouseId;
    
    @NotNull(message = "Target warehouse ID is required")
    @Positive(message = "Target warehouse ID must be positive")
    private Long targetWarehouseId;
    
    @NotNull(message = "Product ID is required")
    @Positive(message = "Product ID must be positive")
    private Long productId;
    
    @NotNull(message = "Quantity is required")
    @Min(value = 1, message = "Quantity must be at least 1")
    private Integer quantity;
    
    @Size(max = 500, message = "Remarks cannot exceed 500 characters")
    private String remarks;
    
    private String initiatedBy;
}