
package com.example.warehouse.repository;

import com.example.warehouse.entity.Warehouse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WarehouseRepository extends JpaRepository<Warehouse, Long> {
    
   
    Optional<Warehouse> findByIdAndStatusNot(Long id, String status);
    
 
    Page<Warehouse> findByStatusNot(String status, Pageable pageable);
    
 
    boolean existsByNameAndStatusNot(String name, String status);
}