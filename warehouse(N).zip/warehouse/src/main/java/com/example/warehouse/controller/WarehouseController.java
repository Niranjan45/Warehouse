
package com.example.warehouse.controller;

import com.example.warehouse.dto.request.WarehouseRequest;
import com.example.warehouse.dto.response.WarehouseResponse;
import com.example.warehouse.service.WarehouseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/warehouses")
@RequiredArgsConstructor
@Tag(name = "Warehouse Management", description = "APIs for managing warehouses")
@Slf4j
public class WarehouseController {
    
    private final WarehouseService warehouseService;
    
    @PostMapping
    @Operation(summary = "Create a new warehouse")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Warehouse created successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input"),
        @ApiResponse(responseCode = "409", description = "Warehouse with same name exists")
    })
    public ResponseEntity<WarehouseResponse> createWarehouse(@Valid @RequestBody WarehouseRequest request) {
        log.info("REST request to create warehouse: {}", request.getName());
        WarehouseResponse response = warehouseService.createWarehouse(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get warehouse by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Warehouse found"),
        @ApiResponse(responseCode = "404", description = "Warehouse not found")
    })
    public ResponseEntity<WarehouseResponse> getWarehouse(@PathVariable Long id) {
        log.debug("REST request to get warehouse with id: {}", id);
        WarehouseResponse response = warehouseService.getWarehouse(id);
        return ResponseEntity.ok(response);
    }
    
    @PutMapping("/{id}")
    @Operation(summary = "Update warehouse")
    public ResponseEntity<WarehouseResponse> updateWarehouse(
            @PathVariable Long id, 
            @Valid @RequestBody WarehouseRequest request) {
        log.info("REST request to update warehouse with id: {}", id);
        WarehouseResponse response = warehouseService.updateWarehouse(id, request);
        return ResponseEntity.ok(response);
    }
    
    @PatchMapping("/{id}/deactivate")
    @Operation(summary = "Deactivate warehouse")
    public ResponseEntity<Void> deactivateWarehouse(@PathVariable Long id) {
        log.info("REST request to deactivate warehouse with id: {}", id);
        warehouseService.deactivateWarehouse(id);
        return ResponseEntity.noContent().build();
    }
    
    @PatchMapping("/{id}/activate")
    @Operation(summary = "Activate warehouse")
    public ResponseEntity<Void> activateWarehouse(@PathVariable Long id) {
        log.info("REST request to activate warehouse with id: {}", id);
        warehouseService.activateWarehouse(id);
        return ResponseEntity.noContent().build();
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Soft delete warehouse")
    public ResponseEntity<Void> deleteWarehouse(@PathVariable Long id) {
        log.warn("REST request to soft delete warehouse with id: {}", id);
        warehouseService.deleteWarehouse(id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping
    @Operation(summary = "Get all warehouses with pagination")
  
    public ResponseEntity<Page<WarehouseResponse>> getAllWarehouses(
            @PageableDefault(size = 20, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        log.debug("REST request to get all warehouses");
        Page<WarehouseResponse> warehouses = warehouseService.getAllWarehouses(pageable);
        return ResponseEntity.ok(warehouses);
    }
}