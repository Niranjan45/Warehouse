
package com.example.warehouse.enums;

public enum OperationType {
    DIRECT_ALLOCATION("Direct Allocation"),
    TRANSFER_ALLOCATION("Transfer Allocation"),
    AUTO_SELECTED("Auto Selected"),
    MANUAL_ALLOCATION("Manual Allocation");
    
    private final String description;
    
    OperationType(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return description;
    }
}