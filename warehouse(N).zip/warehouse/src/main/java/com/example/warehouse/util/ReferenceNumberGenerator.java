
package com.example.warehouse.util;

import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Component
public class ReferenceNumberGenerator {
    
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
    
    public String generateAllocationReference() {
        String date = LocalDateTime.now().format(DATE_FORMATTER);
        String uniqueId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        return "ALLOC-" + date + "-" + uniqueId;
    }
    
    public String generateTransferReference() {
        String date = LocalDateTime.now().format(DATE_FORMATTER);
        String uniqueId = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        return "TRANSFER-" + date + "-" + uniqueId;
    }
    
    public String generateOrderReference() {
        String date = LocalDateTime.now().format(DATE_FORMATTER);
        String uniqueId = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        return "ORD-" + date + "-" + uniqueId;
    }
}