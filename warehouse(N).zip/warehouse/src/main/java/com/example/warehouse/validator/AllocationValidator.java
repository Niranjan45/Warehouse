
package com.example.warehouse.validator;

import org.springframework.stereotype.Component;

import com.example.warehouse.entity.Product;
import com.example.warehouse.entity.Warehouse;
import com.example.warehouse.entity.WarehouseInventory;
import com.example.warehouse.exception.InsufficientStockException;
import com.example.warehouse.exception.InvalidOperationException;
import com.example.warehouse.exception.WarehouseCapacityExceededException;

@Component
public class AllocationValidator {
    
    public void validateProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null");
        }
        if (product.getTotalStock() == null || product.getTotalStock() < 0) {
            throw new InvalidOperationException("Invalid product stock information");
        }
    }
    
    public void validateWarehouse(Warehouse warehouse) {
        if (warehouse == null) {
            throw new IllegalArgumentException("Warehouse cannot be null");
        }
        if (!"ACTIVE".equals(warehouse.getStatus())) {
            throw new InvalidOperationException("Warehouse is not active: " + warehouse.getName());
        }
    }
    
    public void validateInventory(WarehouseInventory inventory, Integer requestedQuantity, Warehouse warehouse) {
        if (inventory == null) {
            throw new InsufficientStockException("Product not available in warehouse: " + warehouse.getName());
        }
        
        if (inventory.getAvailableQuantity() < requestedQuantity) {
            throw new InsufficientStockException(
                String.format("Insufficient stock in warehouse %s. Required: %d, Available: %d",
                warehouse.getName(), requestedQuantity, inventory.getAvailableQuantity()));
        }
    }
    
    public void validateCapacity(Warehouse warehouse, int currentStock, int additionalQuantity) {
        if (currentStock + additionalQuantity > warehouse.getCapacity()) {
            throw new WarehouseCapacityExceededException(
                String.format("Warehouse %s capacity would be exceeded. Current: %d, Adding: %d, Capacity: %d",
                warehouse.getName(), currentStock, additionalQuantity, warehouse.getCapacity()));
        }
    }
    
    public void validateQuantity(Integer quantity) {
        if (quantity == null || quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        if (quantity > 100000) {
            throw new IllegalArgumentException("Quantity cannot exceed 100,000 units per request");
        }
    }
}