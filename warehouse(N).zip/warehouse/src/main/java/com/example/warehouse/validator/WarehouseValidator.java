
package com.example.warehouse.validator;

import com.example.warehouse.dto.request.WarehouseRequest;
import com.example.warehouse.entity.Warehouse;
import org.springframework.stereotype.Component;

@Component
public class WarehouseValidator {
    
    public void validateWarehouseRequest(WarehouseRequest request) {
        if (request == null) {
            throw new IllegalArgumentException("Warehouse request cannot be null");
        }
        
        if (request.getName() == null || request.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Warehouse name is required");
        }
        
        if (request.getLocation() == null || request.getLocation().trim().isEmpty()) {
            throw new IllegalArgumentException("Warehouse location is required");
        }
        
        if (request.getCapacity() == null || request.getCapacity() <= 0) {
            throw new IllegalArgumentException("Warehouse capacity must be positive");
        }
        
        if (request.getCapacity() > 1000000) {
            throw new IllegalArgumentException("Warehouse capacity cannot exceed 1,000,000 units");
        }
    }
    
    public void validateWarehouseStatus(Warehouse warehouse, String expectedStatus) {
        if (warehouse == null) {
            throw new IllegalArgumentException("Warehouse cannot be null");
        }
        
        if (!warehouse.getStatus().equals(expectedStatus)) {
            throw new IllegalStateException(
                String.format("Warehouse %s status is %s, expected %s", 
                warehouse.getName(), warehouse.getStatus(), expectedStatus));
        }
    }
    
    public void validateUniqueName(String name, boolean exists) {
        if (exists) {
            throw new IllegalArgumentException("Warehouse with name '" + name + "' already exists");
        }
    }
}