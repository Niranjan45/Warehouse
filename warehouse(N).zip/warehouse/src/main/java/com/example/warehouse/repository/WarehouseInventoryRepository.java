
package com.example.warehouse.repository;

import com.example.warehouse.entity.WarehouseInventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;
import java.util.List;
import java.util.Optional;

@Repository
public interface WarehouseInventoryRepository extends JpaRepository<WarehouseInventory, Long> {
    
    Optional<WarehouseInventory> findByWarehouseIdAndProductId(Long warehouseId, Long productId);
    
    @Lock(LockModeType.OPTIMISTIC)
    @Query("SELECT wi FROM WarehouseInventory wi WHERE wi.warehouse.id = :warehouseId AND wi.product.id = :productId")
    Optional<WarehouseInventory> findByWarehouseIdAndProductIdWithLock(@Param("warehouseId") Long warehouseId, 
                                                                       @Param("productId") Long productId);
    
    List<WarehouseInventory> findByProductId(Long productId);
    
    List<WarehouseInventory> findByWarehouseId(Long warehouseId);
    
    @Query("SELECT wi FROM WarehouseInventory wi WHERE wi.warehouse.status = 'ACTIVE' " +
           "AND wi.product.id = :productId AND wi.availableQuantity >= :requiredQuantity " +
           "ORDER BY wi.availableQuantity DESC")
    List<WarehouseInventory> findBestWarehousesForProduct(@Param("productId") Long productId, 
                                                          @Param("requiredQuantity") Integer requiredQuantity);
    
    @Query("SELECT COALESCE(SUM(wi.availableQuantity), 0) FROM WarehouseInventory wi WHERE wi.product.id = :productId")
    Integer getTotalAvailableStockForProduct(@Param("productId") Long productId);
    
    @Modifying
    @Query("UPDATE WarehouseInventory wi SET wi.availableQuantity = wi.availableQuantity + :quantity " +
           "WHERE wi.warehouse.id = :warehouseId AND wi.product.id = :productId")
    int addStock(@Param("warehouseId") Long warehouseId, 
                 @Param("productId") Long productId, 
                 @Param("quantity") Integer quantity);
    
    @Modifying
    @Query("UPDATE WarehouseInventory wi SET wi.availableQuantity = wi.availableQuantity - :quantity " +
           "WHERE wi.warehouse.id = :warehouseId AND wi.product.id = :productId AND wi.availableQuantity >= :quantity")
    int deductStock(@Param("warehouseId") Long warehouseId, 
                    @Param("productId") Long productId, 
                    @Param("quantity") Integer quantity);
}