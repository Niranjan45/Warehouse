
package com.example.warehouse.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.warehouse.dto.request.AllocationRequest;
import com.example.warehouse.dto.response.AllocationResponse;
import com.example.warehouse.entity.Allocation;
import com.example.warehouse.entity.Product;
import com.example.warehouse.entity.Warehouse;
import com.example.warehouse.entity.WarehouseInventory;
import com.example.warehouse.enums.AllocationStatus;
import com.example.warehouse.enums.WarehouseStatus;
import com.example.warehouse.exception.ConcurrentAllocationException;
import com.example.warehouse.exception.InsufficientStockException;
import com.example.warehouse.exception.ResourceNotFoundException;
import com.example.warehouse.exception.WarehouseCapacityExceededException;
import com.example.warehouse.repository.AllocationRepository;
import com.example.warehouse.repository.ProductRepository;
import com.example.warehouse.repository.WarehouseInventoryRepository;
import com.example.warehouse.repository.WarehouseRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class AllocationService {
 
    private final AllocationRepository allocationRepository;
    private final ProductRepository productRepository;
    private final WarehouseRepository warehouseRepository;
    private final WarehouseInventoryRepository inventoryRepository;
    private final AuditService auditService;
    
    @Transactional
    public AllocationResponse allocateStock(AllocationRequest request) {
        long startTime = System.currentTimeMillis();
        
        try {
            log.info("Processing allocation request for product ID: {}, quantity: {}", 
                    request.getProductId(), request.getQuantity());
            
        
            Product product = productRepository.findById(request.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException("Product not found with ID: " + request.getProductId()));
            
        
            Integer totalAvailable = inventoryRepository.getTotalAvailableStockForProduct(product.getId());
            if (totalAvailable < request.getQuantity()) {
                throw new InsufficientStockException(
                    String.format("Insufficient stock. Required: %d, Available: %d", 
                    request.getQuantity(), totalAvailable));
            }
            
          
            Warehouse warehouse;
            WarehouseInventory inventory;
            
            if (request.getSpecificWarehouseId() != null) {
               
                warehouse = warehouseRepository.findByIdAndStatusNot(
                        request.getSpecificWarehouseId(), WarehouseStatus.DELETED.name())
                        .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found with ID: " + request.getSpecificWarehouseId()));
                
                if (!WarehouseStatus.ACTIVE.name().equals(warehouse.getStatus())) {
                    throw new IllegalStateException("Warehouse is not active");
                }
                
                inventory = getAndLockInventory(warehouse.getId(), product.getId());
                validateInventoryAvailability(inventory, request.getQuantity(), warehouse);
            } else {
               
                List<WarehouseInventory> availableInventories = 
                        inventoryRepository.findBestWarehousesForProduct(product.getId(), request.getQuantity());
                
                if (availableInventories.isEmpty()) {
                    throw new InsufficientStockException("No warehouse with sufficient stock available");
                }
                
                inventory = availableInventories.get(0);
                warehouse = inventory.getWarehouse();
            }
            
            // Step 4: Perform allocation with optimistic locking
            try {
                int newQuantity = inventory.getAvailableQuantity() - request.getQuantity();
                if (newQuantity < 0) {
                    throw new InsufficientStockException("Not enough stock available");
                }
                inventory.setAvailableQuantity(newQuantity);
                inventoryRepository.save(inventory);
            } catch (ObjectOptimisticLockingFailureException e) {
                log.error("Optimistic lock exception during allocation", e);
                throw new ConcurrentAllocationException(
                    "Concurrent allocation conflict. Please retry the operation.");
            }
            
         
            product.setTotalStock(product.getTotalStock() - request.getQuantity());
            productRepository.save(product);
            
        
            Allocation allocation = Allocation.builder()
                    .product(product)
                    .warehouse(warehouse)
                    .quantity(request.getQuantity())
                    .status(AllocationStatus.ALLOCATED.name())
                    .operationType(request.getSpecificWarehouseId() == null ? "AUTO_SELECTED" : "MANUAL_ALLOCATION")
                    .referenceNumber(generateReferenceNumber())
                    .remarks(request.getRemarks())
                    .allocatedBy(request.getAllocatedBy())
                    .allocatedAt(LocalDateTime.now())
                    .build();
            
            Allocation savedAllocation = allocationRepository.save(allocation);
            auditService.logAllocation(savedAllocation.getId(), product.getId(), warehouse.getId(), 
                                        request.getQuantity(), AllocationStatus.ALLOCATED.name());
            
            long responseTime = System.currentTimeMillis() - startTime;
            log.info("Allocation completed successfully in {} ms. Reference: {}", 
                    responseTime, savedAllocation.getReferenceNumber());
            
            if (responseTime > 500) {
                log.warn("Allocation response time exceeded 500ms: {} ms", responseTime);
            }
            
            return mapToResponse(savedAllocation);
            
        } catch (Exception e) {
            log.error("Allocation failed: {}", e.getMessage(), e);
            throw e;
        }
    }
    
    private WarehouseInventory getAndLockInventory(Long warehouseId, Long productId) {
        return inventoryRepository.findByWarehouseIdAndProductIdWithLock(warehouseId, productId)
                .orElseThrow(() -> new ResourceNotFoundException(
                    String.format("Inventory not found for warehouse %d and product %d", warehouseId, productId)));
    }
    
    private void validateInventoryAvailability(WarehouseInventory inventory, Integer quantity, Warehouse warehouse) {
        if (inventory.getAvailableQuantity() < quantity) {
            throw new InsufficientStockException(
                String.format("Insufficient stock in warehouse %s. Required: %d, Available: %d",
                warehouse.getName(), quantity, inventory.getAvailableQuantity()));
        }
        
        // Check capacity after allocation
        int currentTotalStock = inventoryRepository.findByWarehouseId(warehouse.getId())
                .stream()
                .mapToInt(WarehouseInventory::getAvailableQuantity)
                .sum();
        
        if (currentTotalStock + quantity > warehouse.getCapacity()) {
            throw new WarehouseCapacityExceededException(
                String.format("Warehouse %s capacity would be exceeded. Current: %d, Adding: %d, Capacity: %d",
                warehouse.getName(), currentTotalStock, quantity, warehouse.getCapacity()));
        }
    }
    
    private String generateReferenceNumber() {
        return "ALLOC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
    
    private AllocationResponse mapToResponse(Allocation allocation) {
        return AllocationResponse.builder()
                .allocationId(allocation.getId())
                .productId(allocation.getProduct().getId())
                .productSku(allocation.getProduct().getSku())
                .productName(allocation.getProduct().getName())
                .warehouseId(allocation.getWarehouse().getId())
                .warehouseName(allocation.getWarehouse().getName())
                .quantity(allocation.getQuantity())
                .status(allocation.getStatus())
                .operationType(allocation.getOperationType())
                .referenceNumber(allocation.getReferenceNumber())
                .allocatedAt(allocation.getAllocatedAt())
                .remarks(allocation.getRemarks())
                .allocatedBy(allocation.getAllocatedBy())
                .build();
    }
}