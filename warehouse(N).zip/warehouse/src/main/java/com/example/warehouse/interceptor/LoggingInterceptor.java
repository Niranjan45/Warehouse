
package com.example.warehouse.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.UUID;

@Component
@Slf4j
public class LoggingInterceptor implements HandlerInterceptor {
    
    private static final String CORRELATION_ID_HEADER = "X-Correlation-Id";
    private static final String START_TIME_ATTRIBUTE = "startTime";
    
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String correlationId = getCorrelationId(request);
        request.setAttribute(CORRELATION_ID_HEADER, correlationId);
        request.setAttribute(START_TIME_ATTRIBUTE, System.currentTimeMillis());
        
        log.info("[{}] Request: {} {} - CorrelationId: {}", 
            correlationId, request.getMethod(), request.getRequestURI(), correlationId);
        
        response.setHeader(CORRELATION_ID_HEADER, correlationId);
        return true;
    }
    
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, 
                               Object handler, Exception ex) {
        String correlationId = (String) request.getAttribute(CORRELATION_ID_HEADER);
        long startTime = (Long) request.getAttribute(START_TIME_ATTRIBUTE);
        long duration = System.currentTimeMillis() - startTime;
        
        if (ex != null) {
            log.error("[{}] Request failed: {} - Error: {}", correlationId, request.getRequestURI(), ex.getMessage());
        }
        
        log.info("[{}] Response: {} - Status: {} - Duration: {}ms", 
            correlationId, request.getRequestURI(), response.getStatus(), duration);
    }
    
    private String getCorrelationId(HttpServletRequest request) {
        String correlationId = request.getHeader(CORRELATION_ID_HEADER);
        if (correlationId == null || correlationId.isEmpty()) {
            correlationId = UUID.randomUUID().toString();
        }
        return correlationId;
    }
}