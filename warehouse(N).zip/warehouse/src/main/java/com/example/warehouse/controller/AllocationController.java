
package com.example.warehouse.controller;

import java.time.LocalDateTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.warehouse.dto.request.AllocationRequest;
import com.example.warehouse.dto.response.AllocationResponse;
import com.example.warehouse.entity.Allocation;
import com.example.warehouse.repository.AllocationRepository;
import com.example.warehouse.service.AllocationService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/allocations")
@RequiredArgsConstructor
@Tag(name = "Stock Allocation", description = "APIs for stock allocation management")
@Slf4j
public class AllocationController {
 
    private final AllocationService allocationService;
    private final AllocationRepository allocationRepository;
    
    @PostMapping
    @Operation(summary = "Allocate stock to warehouse")
    @ApiResponse(responseCode = "200", description = "Stock allocated successfully")
    public ResponseEntity<AllocationResponse> allocateStock(@Valid @RequestBody AllocationRequest request) {
        log.info("REST request to allocate stock for product: {}, quantity: {}", request.getProductId(), request.getQuantity());
        AllocationResponse response = allocationService.allocateStock(request);
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/search")
    @Operation(summary = "Search allocations with filters")
    public ResponseEntity<Page<AllocationResponse>> searchAllocations(
            @RequestParam(required = false) Long productId,
            @RequestParam(required = false) Long warehouseId,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate,
            @PageableDefault(size = 20, sort = "allocatedAt", direction = Sort.Direction.DESC) Pageable pageable) {
        
        log.debug("REST request to search allocations with filters");
        Page<AllocationResponse> allocations = allocationRepository.searchAllocations(
                productId, warehouseId, status, startDate, endDate, pageable)
                .map(this::mapToResponse);
        
        return ResponseEntity.ok(allocations);
    }
    
    private AllocationResponse mapToResponse(Allocation allocation) {
        return AllocationResponse.builder()
                .allocationId(allocation.getId())
                .productId(allocation.getProduct().getId())
                .productSku(allocation.getProduct().getSku())
                .productName(allocation.getProduct().getName())
                .warehouseId(allocation.getWarehouse().getId())
                .warehouseName(allocation.getWarehouse().getName())
                .quantity(allocation.getQuantity())
                .status(allocation.getStatus())
                .operationType(allocation.getOperationType())
                .referenceNumber(allocation.getReferenceNumber())
                .allocatedAt(allocation.getAllocatedAt())
                .remarks(allocation.getRemarks())
                .allocatedBy(allocation.getAllocatedBy())
                .build();
    }
}