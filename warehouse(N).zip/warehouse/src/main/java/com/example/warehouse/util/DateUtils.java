
package com.example.warehouse.util;

import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

@Component
public class DateUtils {
    
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    
    public static String formatDateTime(LocalDateTime dateTime) {
        return dateTime != null ? dateTime.format(FORMATTER) : null;
    }
    
    public static long getDaysBetween(LocalDateTime start, LocalDateTime end) {
        return ChronoUnit.DAYS.between(start, end);
    }
    
    public static boolean isExpired(LocalDateTime dateTime, int expirationDays) {
        if (dateTime == null) return false;
        LocalDateTime expirationDate = dateTime.plusDays(expirationDays);
        return LocalDateTime.now().isAfter(expirationDate);
    }
    
    public static LocalDateTime getStartOfDay(LocalDateTime dateTime) {
        return dateTime != null ? dateTime.truncatedTo(ChronoUnit.DAYS) : null;
    }
    
    public static LocalDateTime getEndOfDay(LocalDateTime dateTime) {
        return dateTime != null ? dateTime.truncatedTo(ChronoUnit.DAYS).plusDays(1).minusSeconds(1) : null;
    }
}