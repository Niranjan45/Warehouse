
package com.example.warehouse.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.concurrent.ConcurrentHashMap;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuditService {
    
    private final ConcurrentHashMap<String, String> auditLogs = new ConcurrentHashMap<>();
    
    public void logAllocation(Long allocationId, Long productId, Long warehouseId, Integer quantity, String status) {
        String auditEntry = String.format(
            "[%s] ALLOCATION - ID: %d, Product: %d, Warehouse: %d, Quantity: %d, Status: %s",
            LocalDateTime.now(), allocationId, productId, warehouseId, quantity, status
        );
        log.info(auditEntry);
        auditLogs.put("ALLOC_" + allocationId + "_" + System.currentTimeMillis(), auditEntry);
    }
    
    public void logStockTransfer(Long transferId, Long sourceWarehouse, Long targetWarehouse, 
                                  Long productId, Integer quantity, String status) {
        String auditEntry = String.format(
            "[%s] TRANSFER - ID: %d, Source: %d, Target: %d, Product: %d, Quantity: %d, Status: %s",
            LocalDateTime.now(), transferId, sourceWarehouse, targetWarehouse, productId, quantity, status
        );
        log.info(auditEntry);
        auditLogs.put("TRF_" + transferId + "_" + System.currentTimeMillis(), auditEntry);
    }
    
    public void logWarehouseAction(Long warehouseId, String action, String status) {
        String auditEntry = String.format(
            "[%s] WAREHOUSE - ID: %d, Action: %s, Status: %s",
            LocalDateTime.now(), warehouseId, action, status
        );
        log.info(auditEntry);
        auditLogs.put("WH_" + warehouseId + "_" + System.currentTimeMillis(), auditEntry);
    }
    
    public void logProductAction(Long productId, String action, String details) {
        String auditEntry = String.format(
            "[%s] PRODUCT - ID: %d, Action: %s, Details: %s",
            LocalDateTime.now(), productId, action, details
        );
        log.info(auditEntry);
        auditLogs.put("PROD_" + productId + "_" + System.currentTimeMillis(), auditEntry);
    }
}