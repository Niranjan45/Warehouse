
package com.example.warehouse.enums;

public enum TransferStatus {
    PENDING("Pending"),
    COMPLETED("Completed"),
    FAILED("Failed"),
    CANCELLED("Cancelled");
    
    private final String description;
    
    TransferStatus(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return description;
    }
}