
package com.example.warehouse.repository;

import com.example.warehouse.entity.Allocation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AllocationRepository extends JpaRepository<Allocation, Long> {
    
    Page<Allocation> findByProductId(Long productId, Pageable pageable);
    
    Page<Allocation> findByWarehouseId(Long warehouseId, Pageable pageable);
    
    @Query("SELECT a FROM Allocation a WHERE a.allocatedAt BETWEEN :startDate AND :endDate")
    Page<Allocation> findByDateRange(@Param("startDate") LocalDateTime startDate,
                                     @Param("endDate") LocalDateTime endDate,
                                     Pageable pageable);
    
    @Query("SELECT a FROM Allocation a WHERE " +
           "(:productId IS NULL OR a.product.id = :productId) AND " +
           "(:warehouseId IS NULL OR a.warehouse.id = :warehouseId) AND " +
           "(:status IS NULL OR a.status = :status) AND " +
           "(:startDate IS NULL OR a.allocatedAt >= :startDate) AND " +
           "(:endDate IS NULL OR a.allocatedAt <= :endDate)")
    Page<Allocation> searchAllocations(@Param("productId") Long productId,
                                       @Param("warehouseId") Long warehouseId,
                                       @Param("status") String status,
                                       @Param("startDate") LocalDateTime startDate,
                                       @Param("endDate") LocalDateTime endDate,
                                       Pageable pageable);
    
    List<Allocation> findByReferenceNumber(String referenceNumber);
    
    @Query("SELECT a FROM Allocation a WHERE a.product.id = :productId AND a.status = 'ALLOCATED'")
    List<Allocation> findActiveAllocationsByProduct(@Param("productId") Long productId);
    
    // FIXED: Changed method name and added proper @Query
    @Query("SELECT COALESCE(SUM(a.quantity), 0) FROM Allocation a WHERE a.product.id = :productId AND a.status = 'ALLOCATED'")
    Integer getTotalAllocatedQuantity(@Param("productId") Long productId);
}