
package com.example.warehouse.exception;

@SuppressWarnings("serial")
public class WarehouseCapacityExceededException extends RuntimeException {
    public WarehouseCapacityExceededException(String message) {
        super(message);
    }
}