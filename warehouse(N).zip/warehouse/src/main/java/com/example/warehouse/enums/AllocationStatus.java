
package com.example.warehouse.enums;

public enum AllocationStatus {
    ALLOCATED("Allocated"),
    CANCELLED("Cancelled"),
    COMPLETED("Completed");
    
    private final String description;
    
    AllocationStatus(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return description;
    }
}