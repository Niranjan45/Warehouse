
package com.example.warehouse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Entity
@Table(name = "allocations")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class Allocation {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    // IMPORTANT: This 'product' field is what the Product entity maps to
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "warehouse_id", nullable = false)
    private Warehouse warehouse;
    
    @Column(nullable = false)
    private Integer quantity;
    
    @Column(nullable = false, length = 20)
    private String status;
    
    @Column(nullable = false, length = 30)
    private String operationType;
    
    @Column(nullable = false, unique = true, length = 50)
    private String referenceNumber;
    
    @Column(length = 500)
    private String remarks;
    
    private String allocatedBy;
    
    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime allocatedAt;
    
    private LocalDateTime completedAt;
    private LocalDateTime cancelledAt;
}