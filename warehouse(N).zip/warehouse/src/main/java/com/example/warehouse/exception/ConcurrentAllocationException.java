
package com.example.warehouse.exception;

@SuppressWarnings("serial")
public class ConcurrentAllocationException extends RuntimeException {
    public ConcurrentAllocationException(String message) {
        super(message);
    }
}