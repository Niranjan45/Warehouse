
package com.example.warehouse.service;

import com.example.warehouse.dto.request.StockTransferRequest;
import com.example.warehouse.dto.response.StockTransferResponse;
import com.example.warehouse.entity.Product;
import com.example.warehouse.entity.StockTransfer;
import com.example.warehouse.entity.Warehouse;
import com.example.warehouse.entity.WarehouseInventory;
import com.example.warehouse.enums.TransferStatus;
import com.example.warehouse.enums.WarehouseStatus;
import com.example.warehouse.exception.InsufficientStockException;
import com.example.warehouse.exception.InvalidOperationException;
import com.example.warehouse.exception.ResourceNotFoundException;
import com.example.warehouse.repository.ProductRepository;
import com.example.warehouse.repository.StockTransferRepository;
import com.example.warehouse.repository.WarehouseInventoryRepository;
import com.example.warehouse.repository.WarehouseRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class StockTransferService {
    
    private final StockTransferRepository stockTransferRepository;
    private final WarehouseRepository warehouseRepository;
    private final ProductRepository productRepository;
    private final WarehouseInventoryRepository inventoryRepository;
    private final AuditService auditService;
    
    public StockTransferResponse transferStock(StockTransferRequest request) {
        log.info("Processing stock transfer from warehouse {} to {}", request.getSourceWarehouseId(), request.getTargetWarehouseId());
        
        
        Warehouse sourceWarehouse = warehouseRepository.findByIdAndStatusNot(request.getSourceWarehouseId(), WarehouseStatus.DELETED.name())
                .orElseThrow(() -> new ResourceNotFoundException("Source warehouse not found"));
        
        Warehouse targetWarehouse = warehouseRepository.findByIdAndStatusNot(request.getTargetWarehouseId(), WarehouseStatus.DELETED.name())
                .orElseThrow(() -> new ResourceNotFoundException("Target warehouse not found"));
        
        if (!sourceWarehouse.getStatus().equals(WarehouseStatus.ACTIVE.name()) || 
            !targetWarehouse.getStatus().equals(WarehouseStatus.ACTIVE.name())) {
            throw new InvalidOperationException("Both warehouses must be active for transfer");
        }
        
        if (sourceWarehouse.getId().equals(targetWarehouse.getId())) {
            throw new InvalidOperationException("Source and target warehouses cannot be the same");
        }
        
      
        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new ResourceNotFoundException("Product not found"));
        
      
        WarehouseInventory sourceInventory = inventoryRepository.findByWarehouseIdAndProductId(sourceWarehouse.getId(), product.getId())
                .orElseThrow(() -> new InsufficientStockException("Product not available in source warehouse"));
        
        if (sourceInventory.getAvailableQuantity() < request.getQuantity()) {
            throw new InsufficientStockException(
                String.format("Insufficient stock in source warehouse. Available: %d, Requested: %d",
                sourceInventory.getAvailableQuantity(), request.getQuantity()));
        }
        
       
        int targetCurrentStock = inventoryRepository.findByWarehouseId(targetWarehouse.getId())
                .stream()
                .mapToInt(WarehouseInventory::getAvailableQuantity)
                .sum();
        
        if (targetCurrentStock + request.getQuantity() > targetWarehouse.getCapacity()) {
            throw new InsufficientStockException("Target warehouse capacity would be exceeded");
        }
        
        StockTransfer transfer = StockTransfer.builder()
                .sourceWarehouse(sourceWarehouse)
                .targetWarehouse(targetWarehouse)
                .product(product)
                .quantity(request.getQuantity())
                .status(TransferStatus.PENDING.name())
                .transferNumber(generateTransferNumber())
                .remarks(request.getRemarks())
                .initiatedBy(request.getInitiatedBy())
                .build();
        
        StockTransfer savedTransfer = stockTransferRepository.save(transfer);
        auditService.logStockTransfer(savedTransfer.getId(), sourceWarehouse.getId(), targetWarehouse.getId(),
                                      product.getId(), request.getQuantity(), TransferStatus.PENDING.name());
        log.info("Stock transfer created with number: {}", savedTransfer.getTransferNumber());
        
        return mapToResponse(savedTransfer);
    }
    
    public StockTransferResponse completeTransfer(Long transferId) {
        log.info("Completing stock transfer with ID: {}", transferId);
        
        StockTransfer transfer = stockTransferRepository.findById(transferId)
                .orElseThrow(() -> new ResourceNotFoundException("Transfer not found"));
        
        if (!transfer.getStatus().equals(TransferStatus.PENDING.name())) {
            throw new InvalidOperationException("Transfer is not in pending state");
        }
        
       
        int deducted = inventoryRepository.deductStock(transfer.getSourceWarehouse().getId(), 
                transfer.getProduct().getId(), transfer.getQuantity());
        
        if (deducted == 0) {
            transfer.setStatus(TransferStatus.FAILED.name());
            stockTransferRepository.save(transfer);
            throw new InsufficientStockException("Failed to deduct stock from source warehouse");
        }
       
        inventoryRepository.addStock(transfer.getTargetWarehouse().getId(), 
                transfer.getProduct().getId(), transfer.getQuantity());
        
        transfer.setStatus(TransferStatus.COMPLETED.name());
        transfer.setCompletedAt(LocalDateTime.now());
        
        StockTransfer completedTransfer = stockTransferRepository.save(transfer);
        auditService.logStockTransfer(completedTransfer.getId(), transfer.getSourceWarehouse().getId(),
                                      transfer.getTargetWarehouse().getId(), transfer.getProduct().getId(),
                                      transfer.getQuantity(), TransferStatus.COMPLETED.name());
        log.info("Stock transfer completed successfully: {}", completedTransfer.getTransferNumber());
        
        return mapToResponse(completedTransfer);
    }
    
    public StockTransferResponse cancelTransfer(Long transferId) {
        log.info("Cancelling stock transfer with ID: {}", transferId);
        
        StockTransfer transfer = stockTransferRepository.findById(transferId)
                .orElseThrow(() -> new ResourceNotFoundException("Transfer not found"));
        
        if (!transfer.getStatus().equals(TransferStatus.PENDING.name())) {
            throw new InvalidOperationException("Only pending transfers can be cancelled");
        }
        
        transfer.setStatus(TransferStatus.CANCELLED.name());
        transfer.setCancelledAt(LocalDateTime.now());
        
        StockTransfer cancelledTransfer = stockTransferRepository.save(transfer);
        auditService.logStockTransfer(cancelledTransfer.getId(), transfer.getSourceWarehouse().getId(),
                                      transfer.getTargetWarehouse().getId(), transfer.getProduct().getId(),
                                      transfer.getQuantity(), TransferStatus.CANCELLED.name());
        log.info("Stock transfer cancelled: {}", cancelledTransfer.getTransferNumber());
        
        return mapToResponse(cancelledTransfer);
    }
    
    @Transactional(readOnly = true)
    public Page<StockTransferResponse> getAllTransfers(Pageable pageable) {
        return stockTransferRepository.findAll(pageable)
                .map(this::mapToResponse);
    }
    
    @Transactional(readOnly = true)
    public StockTransferResponse getTransferById(Long id) {
        StockTransfer transfer = stockTransferRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Transfer not found with ID: " + id));
        return mapToResponse(transfer);
    }
    
    private String generateTransferNumber() {
        return "TRF-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
    }
    
    private StockTransferResponse mapToResponse(StockTransfer transfer) {
        return StockTransferResponse.builder()
                .transferId(transfer.getId())
                .sourceWarehouseId(transfer.getSourceWarehouse().getId())
                .sourceWarehouseName(transfer.getSourceWarehouse().getName())
                .targetWarehouseId(transfer.getTargetWarehouse().getId())
                .targetWarehouseName(transfer.getTargetWarehouse().getName())
                .productId(transfer.getProduct().getId())
                .productName(transfer.getProduct().getName())
                .productSku(transfer.getProduct().getSku())
                .quantity(transfer.getQuantity())
                .status(transfer.getStatus())
                .transferNumber(transfer.getTransferNumber())
                .transferDate(transfer.getTransferDate())
                .completedAt(transfer.getCompletedAt())
                .remarks(transfer.getRemarks())
                .build();
    }
}