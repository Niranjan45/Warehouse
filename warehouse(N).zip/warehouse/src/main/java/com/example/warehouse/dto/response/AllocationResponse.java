// src/main/java/com/example/warehouse/dto/response/AllocationResponse.java
package com.example.warehouse.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AllocationResponse {
    private Long allocationId;
    private Long productId;
    private String productSku;
    private String productName;
    private Long warehouseId;
    private String warehouseName;
    private Integer quantity;
    private String status;
    private String operationType;
    private String referenceNumber;
    private LocalDateTime allocatedAt;
    private String remarks;
    private String allocatedBy;
}