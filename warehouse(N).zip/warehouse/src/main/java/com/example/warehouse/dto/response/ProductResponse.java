package com.example.warehouse.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductResponse {
    private Long id;
    private String name;
    private String sku;
    private String category;
    private Integer totalStock;
    private Integer minimumStockLevel;
    private Integer maximumStockLevel;
    private String description;
    private LocalDateTime createdAt;
    private Integer totalAllocatedStock;
    private Boolean isLowStock;
}