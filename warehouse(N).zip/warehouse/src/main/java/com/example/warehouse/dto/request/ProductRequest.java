
package com.example.warehouse.dto.request;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductRequest {
    
    @NotBlank(message = "Product name is required")
    @Size(min = 2, max = 200, message = "Name must be between 2 and 200 characters")
    private String name;
    
    @NotBlank(message = "SKU is required")
    @Pattern(regexp = "^[A-Z0-9-]+$", message = "SKU must contain only uppercase letters, numbers, and hyphens")
    private String sku;
    
    @NotBlank(message = "Category is required")
    private String category;
    
    @NotNull(message = "Total stock is required")
    @Min(value = 0, message = "Total stock cannot be negative")
    private Integer totalStock;
    
    @Min(value = 0, message = "Minimum stock level cannot be negative")
    private Integer minimumStockLevel;
    
    @Min(value = 0, message = "Maximum stock level cannot be negative")
    private Integer maximumStockLevel;
    
    @Size(max = 1000, message = "Description cannot exceed 1000 characters")
    private String description;
}