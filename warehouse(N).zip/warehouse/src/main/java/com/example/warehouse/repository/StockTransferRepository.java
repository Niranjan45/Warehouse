
package com.example.warehouse.repository;

import com.example.warehouse.entity.StockTransfer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StockTransferRepository extends JpaRepository<StockTransfer, Long> {
    
    List<StockTransfer> findByStatus(String status);
    
    @Query("SELECT st FROM StockTransfer st WHERE st.sourceWarehouse.id = :warehouseId OR st.targetWarehouse.id = :warehouseId")
    Page<StockTransfer> findByWarehouseId(@Param("warehouseId") Long warehouseId, Pageable pageable);
    
    @Query("SELECT st FROM StockTransfer st WHERE st.product.id = :productId")
    Page<StockTransfer> findByProductId(@Param("productId") Long productId, Pageable pageable);
    
    List<StockTransfer> findByTransferNumber(String transferNumber);
}