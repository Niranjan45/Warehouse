// src/main/java/com/example/warehouse/dto/response/StockTransferResponse.java
package com.example.warehouse.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StockTransferResponse {
    private Long transferId;
    private Long sourceWarehouseId;
    private String sourceWarehouseName;
    private Long targetWarehouseId;
    private String targetWarehouseName;
    private Long productId;
    private String productName;
    private String productSku;
    private Integer quantity;
    private String status;
    private String transferNumber;
    private LocalDateTime transferDate;
    private LocalDateTime completedAt;
    private String remarks;
}