
package com.example.warehouse.enums;

public enum WarehouseStatus {
    ACTIVE("Active"),
    INACTIVE("Inactive"),
    DELETED("Soft Deleted");
    
    private final String description;
    
    WarehouseStatus(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return description;
    }
}