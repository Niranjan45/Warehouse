
package com.example.warehouse.interceptor;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Component
@Slf4j
public class PerformanceInterceptor implements HandlerInterceptor {
    
    private final ConcurrentHashMap<String, AtomicLong> endpointMetrics = new ConcurrentHashMap<>();
    
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        request.setAttribute("performanceStartTime", System.currentTimeMillis());
        return true;
    }
    
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, 
                               Object handler, Exception ex) {
        long startTime = (Long) request.getAttribute("performanceStartTime");
        long duration = System.currentTimeMillis() - startTime;
        String endpoint = request.getRequestURI();
        
        // Track metrics
        endpointMetrics.computeIfAbsent(endpoint, k -> new AtomicLong()).addAndGet(duration);
        
        // Log slow requests
        if (duration > 500) {
            log.warn("Slow request detected: {} {} took {}ms", 
                request.getMethod(), endpoint, duration);
        }
        
        // Update average
        long totalTime = endpointMetrics.get(endpoint).get();
        long requestCount = endpointMetrics.get(endpoint).get() / duration;
        long averageTime = requestCount > 0 ? totalTime / requestCount : duration;
        
        log.debug("Performance stats for {}: Avg: {}ms, Last: {}ms", endpoint, averageTime, duration);
    }
    
    public ConcurrentHashMap<String, AtomicLong> getEndpointMetrics() {
        return endpointMetrics;
    }
}