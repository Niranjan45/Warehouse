
package com.example.warehouse.repository;

import com.example.warehouse.entity.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    
    Optional<Product> findBySku(String sku);
    
    boolean existsBySku(String sku);
    
    Page<Product> findAll(Pageable pageable);
    
    @Query("SELECT p FROM Product p WHERE p.totalStock < p.minimumStockLevel")
    List<Product> findLowStockProducts();
    
    @Query("SELECT COALESCE(SUM(a.quantity), 0) FROM Allocation a WHERE a.product.id = :productId AND a.status = 'ALLOCATED'")
    Integer getTotalAllocatedQuantity(@Param("productId") Long productId);
}